# PathoBench 재현용 — 라벨 & 공식 fold 번들

다른 서버에서 PathoBench 평가를 재현하기 위한 **라벨 + 공식 fold 정보** 모음입니다.
**(원시 피처 h5는 이 번들에 포함되지 않음** — 대상 서버에 이미 있다고 가정하며,
`features/{DATASET}/*.h5`는 `/NHNHOME/kimds/Data/PathoBench/features/`와 동일 구조로 두면 됩니다.)

출처: 공식 **Patho-Bench** (Mahmood Lab, arXiv:2502.06750, HF `MahmoodLab/Patho-Bench`).

## 폴더 구조

```
repro_labels_folds/
├── README.md
├── official/                        # 공식 원본 (가장 권위 있는 소스)
│   └── {source}/{task}/
│       ├── k=all.tsv                # case_id, slide_id, <task_col>, fold_0..fold_N
│       └── config.yaml              # task_col, label_dict, task_type, sample_col
├── labels/                          # 슬라이드 단위 라벨 CSV (편의용)
│   └── {source}_{task}.csv          # slide_id, label, split(fold_0)
└── fold5/                           # 공식 5-fold CSV (재현용 핵심)
    └── {source}_{task}.csv          # slide_id, label, fold_0..fold_4
```

## 라벨

- **권위 소스**: `official/{source}/{task}/k=all.tsv`의 `<task_col>` 컬럼.
  컬럼명/의미는 같은 폴더 `config.yaml`이 정의 (`task_col`, `label_dict`, `task_type`).
- **편의용**: `labels/{source}_{task}.csv` — 슬라이드 단위 `slide_id, label, split`
  (split은 공식 fold_0 기준 train/val/test).
- 참고:
  - `task_type: survival` task(예: `*_OS`)는 라벨이 0~7 **복합 값**(OS_days 사분위 + event)이고
    원시 생존 요소는 `extra_cols`(OS_event, OS_days)에 있다. 이진 AUROC로 쓰려면 재처리 필요.
  - 3클래스 task(예: `Immune_class`)는 그대로 저장됨 — 이진화는 사용자 몫.

## 공식 fold (5-fold 재현)

- `k=all.tsv`의 `fold_0..fold_N` 컬럼 각각이 해당 fold의 **train/val/test 배정**이다.
  (test는 전 fold에 걸쳐 동일하게 유지되고, train/val만 StratifiedKFold로 회전 — Patho-Bench 계약.)
- **`fold5/*.csv`**가 "공식 5-fold" 재현용 핵심 파일:
  - 컬럼: `slide_id, label, fold_0, fold_1, fold_2, fold_3, fold_4`
  - fold k에서: `fold_k == 'test'` → 테스트, `fold_k == 'train'` → 트레인, `fold_k == 'val'` → (선택) val/폐기.
  - 대부분 task는 50-fold 중 앞 5개를, OS·bracs task는 원래 5개를 그대로 사용.

## 평가 코드와의 연결

- 로컬 저장소 `scripts/test_pathobench.py`는 `--cv-folds N`일 때 **자체 stratified fold**(seed 42)로
  재분할한다 — **공식 fold 재현에는 사용 불가**. 공식 fold로 재현하려면 `fold5/*.csv`(또는
  `official/.../k=all.tsv`)의 fold 배정을 직접 읽어 train/test를 구성하면 된다.
- 피처 경로: `--features /경로/features` (h5), 모델 input_dim 1536이면 raw 사용, 512면 train-only PCA.

## task 명 대응 (공식 → 기존 로컬 명)

| 공식 (source/task) | 로컬 csv 명 |
|---|---|
| bc_therapy/er_status · grade · her2_status · residual_cancer_burden | bc_therapy_er · grade · her2 · residual |
| cptac_brca/TP53_mutation · PIK3CA_mutation · Immune_class | cptac_brca_tp53 · pik3ca · immune |
| cptac_lscc/ARID1A_mutation · Histologic_Grade · KEAP1_mutation · Immune_class | cptac_lscc_arid1a · histologic · keap1 · immune |
| cptac_luad/STK11_mutation · TP53_mutation · EGFR_mutation · KRAS_mutation · OS · Immune_class | cptac_luad_stk11 · tp53 · egfr · kras · os · immune |
| cptac_pda/SMAD4_mutation · OS · Immune_class | cptac_pda_smad4 · os · immune |
| cptac_ccrcc/BAP1_mutation · PBRM1_mutation · VHL_mutation · Immune_class · OS | (기존 로컬 `cptac_ccrcc_{er,grade,her2,residual}`은 **오류** — 폐기) |
| ucla_lung/progression_regression | ucla_lung_progression_regression |
| mbc_/OS · Recist | mbc_os · mbc_recist |
| bracs/slidelevel_coarse · slidelevel_fine | bracs_coarse · bracs_fine |
| herroi/response | herroi_response |

## 재생성 방법 (원본 서버)

```bash
python scripts/fetch_pathobench_official.py            # official/ 재다운로드
python scripts/build_pathobench_official_csvs.py       # labels/ 생성
# fold5/ 는 공식 k=all.tsv에서 fold_0..4 추출
```

## 현재 상태 (2026-08-07)

- 백그라운드에서 v34-1536으로 실제 `cptac_ccrcc` 이진 task(BAP1/PBRM1/VHL) 5-fold CV 실행 중.
- 본 번들은 그 재현(및 전체 17+ task 재현)에 필요한 라벨·공식 fold를 담는다.
